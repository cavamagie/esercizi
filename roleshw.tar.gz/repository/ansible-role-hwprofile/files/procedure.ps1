#############################################################

$NATIVEVLAN = "VLAN0152"
$NETLIST1 = "VLAN0152","VLAN0150","VLAN0151","VLAN0153"
$NETLIST2 = "VLAN0002","VLAN0003","VLAN0004","VLAN0005","VLAN0010","VLAN0011","VLAN0012","VLAN0013","VLAN0014","VLAN0015"


$strESXiName = "vmwxxyy001"
$strEnclosureName = "bl100mo2.dominio.priv"
$strLogicalEnclosureName = "BL10XMO2-EG"

$Username = 'DOMINIO\UXXYYZZ'
$Password = 'ABCDEFGH'
$SecurePassword = ConvertTo-SecureString -AsPlainText $Password -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $Username,$SecurePassword

# $Credential = Get-Credential

$ConnectedSessions | Disconnect-OVMgmt -ErrorAction SilentlyContinue|Out-Null
Connect-OVMgmt -Credential $Credential -Hostname $strEnclosureName

$BaseLine = Get-OVBaseline -Name "HPE Synergy Service Pack"

$EnclosureName = (Get-OVEnclosure -Name $strEnclosureName -ApplianceConnection $strEnclosureName)

$EnclosureGroup = (Get-OVEnclosureGroup -ApplianceConnection $strEnclosureName -Name $strLogicalEnclosureName)

$HWServerType = Get-OVServerHardwareTypes -name "SY 480 Gen10 1" -ApplianceConnection $strEnclosureName

$BiosSettings = @( `
@{id="WorkloadProfile";value="Custom"}, `
@{id="AutoPowerOn";value="AlwaysPowerOff"}, `
@{id="UsbControl";value="ExternalUsbDisabled"}, `
@{id="InternalSDCardSlot";value="Disabled"}, `
@{id="WakeOnLan"; value="Enabled"}, `
@{id="PowerRegulator";value="OsControl"}, `
@{id="TimeZone";value="UtcP1"}, `
@{id="NumaGroupSizeOpt";value="Clustered"})

If (Get-OVServerProfile -Name "$strESXiName" -ErrorAction SilentlyContinue -WarningAction SilentlyContinue) {
Get-OVServerProfile -Name "$strESXiName"|Remove-OVServerProfile -Confirm:$false
Sleep 3
}

If (-Not (Get-OVServerProfile -Name "$strESXiName" -ErrorAction SilentlyContinue -WarningAction SilentlyContinue)) {
If (Get-OVNetworkSet -Name "$strESXiName-mgmt" -ApplianceConnection $strEnclosureName -ErrorAction SilentlyContinue -WarningAction SilentlyContinue) {
Get-OVNetworkSet -Name "$strESXiName-mgmt" -ApplianceConnection $strEnclosureName| Remove-OVNetworkSet -Confirm:$false | Wait-OVTaskComplete
}

If (Get-OVNetworkSet -Name "$strESXiName-vms" -ApplianceConnection $strEnclosureName -ErrorAction SilentlyContinue -WarningAction SilentlyContinue) {
Get-OVNetworkSet -Name "$strESXiName-vms" -ApplianceConnection $strEnclosureName| Remove-OVNetworkSet -Confirm:$false | Wait-OVTaskComplete
}
}

If (-Not (Get-OVServerProfile -Name "$strESXiName" -ErrorAction SilentlyContinue -WarningAction SilentlyContinue)) {
$netset1 = New-OVNetworkSet -name "$strESXiName-mgmt" -networks $NETLIST1 -UntaggedNetwork "$NATIVEVLAN" -TypicalBandwidth 8000 -MaximumBandwidth 20000 -ApplianceConnection $strEnclosureName
$netset2 = New-OVNetworkSet -name "$strESXiName-vms" -networks $NETLIST2 -TypicalBandwidth 4000 -MaximumBandwidth 20000 -ApplianceConnection $strEnclosureName

$con1 = New-OVServerProfileConnection -ConnectionID 1 -ConnectionType Ethernet -Network (Get-OVNetworkSet -Name "$strESXiName-mgmt") -Priority Primary -RequestedBW 8000 -Bootable -ApplianceConnection $strEnclosureName
$con2 = New-OVServerProfileConnection -ConnectionID 2 -ConnectionType Ethernet -Network (Get-OVNetworkSet -Name "$strESXiName-mgmt") -Priority Secondary -RequestedBW 8000 -Bootable -ApplianceConnection $strEnclosureName

$con3 = Get-OVNetwork -Name "SAN_A" | New-OVServerProfileConnection -ConnectionID 3 -ConnectionType FibreChannel -RequestedBW 8000 -ApplianceConnection $strEnclosureName
$con4 = Get-OVNetwork -Name "SAN_B" | New-OVServerProfileConnection -ConnectionID 4 -ConnectionType FibreChannel -RequestedBW 8000 -ApplianceConnection $strEnclosureName

$con5 = New-OVServerProfileConnection -ConnectionID 5 -ConnectionType Ethernet -Network (Get-OVNetworkSet -Name "$strESXiName-vms") -RequestedBW 4000 -ApplianceConnection $strEnclosureName
$con6 = New-OVServerProfileConnection -ConnectionID 6 -ConnectionType Ethernet -Network (Get-OVNetworkSet -Name "$strESXiName-vms") -RequestedBW 4000 -ApplianceConnection $strEnclosureName

$ConList = $con1, $con2, $con3, $con4, $con5, $con6

$LogicalDisk = New-OVServerProfileLogicalDisk -Name "LOGICAL_VOLUME" -RAID RAID1 -NumberofDrives 2 -DriveType Auto -Accelerator Enabled -StorageLocation Internal -Bootable $True
$Controller = New-OVServerProfileLogicalDiskController -ControllerID 'Mezz 1' -Initialize -LogicalDisk $LogicalDisk -Mode RAID -WriteCache Enabled

$task = New-OVServerProfile -Name $strESXiName -Description $strESXiName -AssignmentType Unassigned -Connections $ConList -ServerHardwareType $HWServerType -EnclosureGroup $EnclosureGroup -ManageBoot -BootOrder @("CD","USB","HardDisk","PXE") -BootMode "BIOS" -StorageController $Controller -Bios:$true -BiosSettings $BiosSettings -Baseline $BaseLine -FirmwareInstallMode FirmwareOffline -ForceInstallFirmware:$true -Firmware:$true -FirmwareActivationMode NotScheduled -ApplianceConnection $strEnclosureName| Wait-OVTaskComplete
}

############################################################################

             - AutoPowerOn: "AlwaysPowerOff"
               UsbControl: "ExternalUsbDisabled"
               WorkloadProfile: "Custom"
               InternalSDCardSlot: "Disabled"
               WakeOnLan: "Enabled"
               PowerRegulator: "OsControl"
               TimeZone: "UtcP1"
               NumaGroupSizeOpt: "Clustered"

"overriddenSettings": [

                    {
                        "id": "WorkloadProfile",
                        "value": "Custom"
                    },
                    {
                        "id": "AutoPowerOn",
                        "value": "AlwaysPowerOff"
                    },
                    {
                        "id": "UsbControl",
                        "value": "ExternalUsbDisabled"
                    },
                    {
                        "id": "InternalSDCardSlot",
                        "value": "Disabled"
                    },
                    {
                        "id": "WakeOnLan",
                        "value": "Enabled"
                    },
                    {
                        "id": "PowerRegulator",
                        "value": "OsControl"
                    },
                    {
                        "id": "TimeZone",
                        "value": "UtcP1"
                    },
                    {
                        "id": "NumaGroupSizeOpt",
                        "value": "Clustered"



             - "CD"
             - "USB"                                
             - "HardDisk"
             - "PXE"           
                        {
                            "id": "WorkloadProfile",
                            "value": "Custom"
                        },
                        {
                            "id": "AutoPowerOn",
                            "value": "AlwaysPowerOff"
                        },
                        {
                            "id": "UsbControl",
                            "value": "ExternalUsbDisabled"
                        },
                        {
                            "id": "InternalSDCardSlot",
                            "value": "Disabled"
                        },
                        {
                            "id": "WakeOnLan",
                            "value": "Enabled"
                        },
                        {
                            "id": "PowerRegulator",
                            "value": "OsControl"
                        },
                        {
                            "id": "TimeZone",
                            "value": "UtcP1"
                        },
                        {
                            "id": "NumaGroupSizeOpt",
                            "value": "Clustered"
                    "connections": [
                        {
                            "allocatedMbps": 8000,
                            "allocatedVFs": 0,
                            "boot": {
                                "ethernetBootType": "PXE",
                                "priority": "Primary"
                            },
                            "functionType": "Ethernet",
                            "id": 1,
                            "interconnectPort": 7,
                            "interconnectUri": "/rest/interconnects/ebb965de-28e2-47c7-a730-242c909e94b0",
                            "ipv4": null,
                            "isolatedTrunk": false,
                            "lagName": null,
                            "mac": "1A:DB:20:50:00:39",
                            "macType": "Virtual",
                            "managed": true,
                            "maximumMbps": 20000,
                            "name": "",
                            "networkName": null,
                            "networkUri": "/rest/network-sets/c5d2ef67-9175-4972-9b33-a93ef7320561",
                            "portId": "Mezz 3:1-a",
                            "privateVlanPortType": "None",
                            "requestedMbps": "8000",
                            "requestedVFs": "0",
                            "state": "Deployed",
                            "status": "OK",
                            "wwnn": null,
                            "wwpn": null,
